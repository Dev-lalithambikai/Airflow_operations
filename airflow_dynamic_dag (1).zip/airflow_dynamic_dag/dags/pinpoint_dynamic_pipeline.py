"""
pinpoint_dynamic_pipeline.py
============================
Single entry-point for Airflow's dags/ folder.

This file combines three responsibilities that were previously split across
three files:

  ┌─────────────────────────────────────────────────────────────────┐
  │  SECTION 1 – DAG STORE  (was: dag_store.py)                    │
  │    Persist / load / delete DAG definitions from disk so they   │
  │    survive scheduler restarts.                                  │
  │                                                                 │
  │  SECTION 2 – DAG FACTORY  (was: dynamic_dag_factory.py)        │
  │    Build a brand-new Airflow DAG from a nodes payload,         │
  │    wire task dependencies by executor_sequence_id, and         │
  │    register the DAG so Airflow picks it up immediately.        │
  │                                                                 │
  │  SECTION 3 – BOOTSTRAP  (was: bootstrap_dynamic_dags.py)       │
  │    Replay all persisted definitions on every scheduler /       │
  │    webserver start so no DAG is ever lost after a restart.     │
  └─────────────────────────────────────────────────────────────────┘

Public API (imported by api/build_api.py)
-----------------------------------------
  build_dag_from_payload(payload)  →  (dag_id, dag)
  persist_dag_definition(dag_id, payload)  →  Path
  load_all_persisted_dags()  →  list[dict]
  delete_dag_definition(dag_id)  →  bool
  list_persisted_dag_ids()  →  list[str]
  DYNAMIC_DAG_REGISTRY  →  dict[str, DAG]

Sequencing rules (executor_sequence_id)
----------------------------------------
  [1, 1, 1]  →  all tasks run in parallel        (no dependencies)
  [1, 2, 2]  →  task-1 → (task-2 ∥ task-3)
  [1, 2, 3]  →  task-1 → task-2 → task-3         (strict chain)
  [1, 1, 2]  →  (task-1 ∥ task-2) → task-3

If any task in group N fails, all tasks in group N+1 become
upstream_failed and the entire DAG run is marked FAILED.
"""

from __future__ import annotations

import json
import logging
import os
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import requests
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago

log = logging.getLogger(__name__)


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 1 ── DAG STORE
# Persist DAG definitions to disk so they survive Airflow restarts.
# ══════════════════════════════════════════════════════════════════════════════

# Storage directory – override with env var DYNAMIC_DAG_STORE if needed
_STORE_DIR = Path(os.getenv("DYNAMIC_DAG_STORE", "/opt/airflow/dynamic_dags"))
_STORE_DIR.mkdir(parents=True, exist_ok=True)


def persist_dag_definition(dag_id: str, build_payload: dict) -> Path:
    """
    Write the build payload + dag_id to a JSON file.

    File location: $DYNAMIC_DAG_STORE/<dag_id>.json

    Called by the Build API immediately after a DAG is created so the
    definition can be replayed on the next scheduler restart.
    """
    record = {"dag_id": dag_id, "build_payload": build_payload}
    dest   = _STORE_DIR / f"{dag_id}.json"
    dest.write_text(json.dumps(record, indent=2))
    log.info("DAG definition persisted → %s", dest)
    return dest


def load_all_persisted_dags() -> list[dict]:
    """
    Return every persisted DAG definition as a list of dicts:
      [{"dag_id": "...", "build_payload": {...}}, ...]

    Called at bootstrap time to restore all dynamic DAGs after a restart.
    """
    defs: list[dict] = []
    for f in _STORE_DIR.glob("*.json"):
        try:
            defs.append(json.loads(f.read_text()))
        except Exception as exc:
            log.warning("Could not load persisted DAG from %s: %s", f, exc)
    log.info("Loaded %d persisted DAG definition(s) from %s.", len(defs), _STORE_DIR)
    return defs


def delete_dag_definition(dag_id: str) -> bool:
    """
    Remove the persisted JSON file for dag_id.
    Returns True if the file existed and was deleted, False otherwise.
    """
    path = _STORE_DIR / f"{dag_id}.json"
    if path.exists():
        path.unlink()
        log.info("Deleted persisted definition for DAG '%s'.", dag_id)
        return True
    return False


def list_persisted_dag_ids() -> list[str]:
    """Return a list of all dag_ids that have a persisted definition on disk."""
    return [f.stem for f in _STORE_DIR.glob("*.json")]


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 2 ── DAG FACTORY
# Build Airflow DAGs dynamically from a nodes payload.
# ══════════════════════════════════════════════════════════════════════════════

# Supported engine identifiers (logged for observability; routing is URL-driven)
SUPPORTED_ENGINES = {"NIFI", "PYTHON", "PYHTON", "GENPROC", "RULESET", "DATASET"}

# In-memory registry – Airflow scans globals() in this file for DAG objects.
# build_dag_from_payload() writes here; bootstrap replays from disk into here.
DYNAMIC_DAG_REGISTRY: dict[str, DAG] = {}

_DEFAULT_ARGS = {
    "owner":            "airflow",
    "depends_on_past":  False,
    "email_on_failure": False,
    "email_on_retry":   False,
    "retries":          0,
    "retry_delay":      timedelta(minutes=1),
}


def _call_engine(url: str, payload: dict, headers: dict, timeout: int = 120) -> dict:
    """
    Generic HTTP POST to any engine endpoint.

    Supports NiFi, Python microservice, GenProc, Ruleset, Dataset – all
    exposed as HTTP REST endpoints.  The engine field is used only for
    logging; actual routing is driven by the url in the run-phase payload.

    To add engine-specific behaviour (custom auth, retries, mTLS) add an
    `if engine == "..."` branch here and pass engine as an argument.
    """
    log.info("Calling engine | url=%s | payload keys=%s", url, list(payload.keys()))
    try:
        resp = requests.post(
            url,
            json=payload,
            headers=headers,
            timeout=timeout,
            verify=False,   # set to True or supply a cert bundle in production
        )
        resp.raise_for_status()
        log.info("Engine response [HTTP %s]: %s", resp.status_code, resp.text[:300])
        return resp.json() if resp.content else {}
    except requests.exceptions.HTTPError as exc:
        log.error("HTTP error from engine: %s", exc)
        raise
    except requests.exceptions.ConnectionError as exc:
        log.error("Connection error reaching %s: %s", url, exc)
        raise
    except Exception as exc:
        log.error("Unexpected error calling engine at %s: %s", url, exc)
        raise


def _execute_node(node_id: str, task_key: str, engine: str, **context: Any) -> dict:
    """
    Run-phase callable injected into every PythonOperator task.

    At execution time Airflow passes the dag_run context which carries the
    run-phase conf.  This function:
      1. Reads conf[task_key]  (e.g. conf["Task1"])
      2. Extracts url, headers (popped from json body), timeout
      3. POSTs to the engine endpoint with the remaining json as body
      4. Pushes the engine response to XCom and returns it

    Parameters
    ----------
    node_id  : original node identifier from the build payload (for logging)
    task_key : "Task1" / "Task2" / "Task3" … assigned during the build phase
    engine   : engine type string (NIFI / PYTHON / GENPROC …) for logging
    **context: Airflow task context injected by provide_context=True
    """
    dag_run_conf: dict = context["dag_run"].conf or {}
    log.info("[%s] dag_run conf keys: %s", node_id, list(dag_run_conf.keys()))

    task_conf: dict = dag_run_conf.get(task_key)
    if not task_conf:
        raise ValueError(
            f"Node '{node_id}' expected conf key '{task_key}' but it was absent. "
            f"Available keys: {list(dag_run_conf.keys())}"
        )

    url: str       = task_conf.get("url", "")
    json_body: dict = dict(task_conf.get("json", {}))   # copy so we don't mutate conf
    headers: dict  = json_body.pop("headers", {})       # headers live inside json but must
    timeout: int   = json_body.pop("timeout", 120)      # be sent as HTTP headers, not body

    if not url:
        raise ValueError(f"Node '{node_id}': conf['{task_key}'] has no 'url' field.")

    log.info(
        "[%s] engine=%-10s | url=%s | timeout=%ss | body_keys=%s",
        node_id, engine, url, timeout, list(json_body.keys()),
    )

    result = _call_engine(url, json_body, headers, timeout)
    log.info("[%s] Completed successfully. Response: %s", node_id, result)
    return result   # stored in XCom automatically by Airflow


def build_dag_from_payload(payload: dict) -> tuple[str, DAG]:
    """
    PHASE 1 entry-point – create an Airflow DAG from the nodes payload.

    Steps
    -----
    1. Validate nodes array.
    2. Generate a unique dag_id:  dynamic_{prefix}_{YYYYMMDDHHMMSSffffff}
    3. Group nodes by executor_sequence_id (int).
    4. Assign Task1 / Task2 / … keys in (seq, order) sort order.
    5. Create one PythonOperator per node, task_id = executor_build_id.
    6. Wire >> dependencies between consecutive sequence groups.
    7. Register the DAG in DYNAMIC_DAG_REGISTRY and globals().

    Parameters
    ----------
    payload : the raw build-phase JSON  {"nodes": [...]}

    Returns
    -------
    (dag_id, dag) tuple
    """
    nodes: list[dict] = payload.get("nodes", [])
    if not nodes:
        raise ValueError("Payload must contain at least one node under 'nodes'.")

    # ── Unique dag_id ─────────────────────────────────────────────────────────
    prefix = nodes[0]["executor_build_id"].split("-")[0]
    dag_id = f"dynamic_{prefix}_{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}"
    log.info("Building DAG '%s' with %d node(s).", dag_id, len(nodes))

    # ── Airflow DAG object ────────────────────────────────────────────────────
    dag = DAG(
        dag_id=dag_id,
        default_args=_DEFAULT_ARGS,
        description=f"Dynamically built DAG – {dag_id}",
        schedule_interval=None,              # API-triggered only (Run phase)
        start_date=days_ago(1),
        catchup=False,
        tags=["dynamic", "api-driven"],
        render_template_as_native_obj=True,
    )

    # ── Group nodes by executor_sequence_id ──────────────────────────────────
    groups: dict[int, list[dict]] = defaultdict(list)
    for node in nodes:
        groups[int(node.get("executor_sequence_id", 1))].append(node)
    sorted_sequences = sorted(groups.keys())

    # ── Assign TaskN keys in (seq, order) sorted order ────────────────────────
    ordered_nodes = sorted(
        nodes,
        key=lambda n: (int(n.get("executor_sequence_id", 1)), int(n.get("executor_order_id", 1))),
    )
    node_to_task_key: dict[str, str] = {
        n["id"]: f"Task{i + 1}" for i, n in enumerate(ordered_nodes)
    }

    # ── Create PythonOperator tasks ───────────────────────────────────────────
    airflow_tasks: dict[str, PythonOperator] = {}
    for node in nodes:
        node_id  = node["id"]
        build_id = node["executor_build_id"]      # ← this becomes the task name
        engine   = node.get("engine", "UNKNOWN").upper()
        task_key = node_to_task_key[node_id]

        airflow_tasks[node_id] = PythonOperator(
            task_id=build_id,                     # Rule 1: task name = executor_build_id
            python_callable=_execute_node,
            op_kwargs={"node_id": node_id, "task_key": task_key, "engine": engine},
            provide_context=True,
            dag=dag,
        )

    # ── Wire dependencies between sequence groups ─────────────────────────────
    #
    #   seq  tasks           wiring
    #   ───  ─────           ──────────────────────────────────────────────────
    #   [1]  [A]             no upstream
    #   [2]  [B, C]          A >> B,  A >> C          (fan-out)
    #   [3]  [D]             B >> D,  C >> D           (fan-in)
    #
    prev_group: list[PythonOperator] = []
    for seq in sorted_sequences:
        curr_group = [airflow_tasks[n["id"]] for n in groups[seq]]
        if prev_group:
            for upstream in prev_group:
                for downstream in curr_group:
                    upstream >> downstream
        prev_group = curr_group

    # ── Register so Airflow scheduler picks it up ─────────────────────────────
    DYNAMIC_DAG_REGISTRY[dag_id] = dag
    globals()[dag_id] = dag

    log.info(
        "DAG '%s' registered. Task mapping: %s",
        dag_id,
        {v: k for k, v in node_to_task_key.items()},   # TaskN → node_id
    )
    return dag_id, dag


# ══════════════════════════════════════════════════════════════════════════════
# SECTION 3 ── BOOTSTRAP
# Replay all persisted DAG definitions on every Airflow start.
# Airflow imports this file on startup; the code below runs automatically.
# ══════════════════════════════════════════════════════════════════════════════

log.info("Bootstrap: scanning persisted DAG definitions in %s …", _STORE_DIR)

for _record in load_all_persisted_dags():
    _dag_id       = _record["dag_id"]
    _build_payload = _record["build_payload"]

    if _dag_id in DYNAMIC_DAG_REGISTRY:
        log.debug("Bootstrap: DAG '%s' already in registry – skipping.", _dag_id)
        continue

    try:
        _built_id, _dag = build_dag_from_payload(_build_payload)
        globals()[_built_id] = _dag          # expose to Airflow's DAG scanner
        log.info("Bootstrap: restored DAG '%s'.", _built_id)
    except Exception as _exc:
        log.error("Bootstrap: could not restore DAG '%s': %s", _dag_id, _exc)

log.info(
    "Bootstrap complete. %d DAG(s) active in registry.",
    len(DYNAMIC_DAG_REGISTRY),
)

# ── Expose all registry DAGs to Airflow's global scanner ─────────────────────
# (covers DAGs built after import time via build_dag_from_payload)
for _dag_id, _dag in DYNAMIC_DAG_REGISTRY.items():
    globals()[_dag_id] = _dag
