"""
build_api.py
============
Lightweight Flask application that exposes two REST endpoints:

  POST /api/v1/dag/build
  ----------------------
  PHASE 1 – Build Phase.
  Accepts the nodes JSON, builds the DAG dynamically, persists it, and
  returns the generated dag_id.

  POST /api/v1/dag/run
  --------------------
  PHASE 2 – Run Phase.
  Accepts dag_id + run payload, validates the dag exists, then triggers an
  Airflow DAG run via Airflow's own REST API, forwarding the conf payload.

  GET /api/v1/dag/status/<dag_run_id>
  ------------------------------------
  Poll a DAG run's status (delegates to Airflow REST API).

  GET /api/v1/dag/list
  --------------------
  List all dynamically built DAGs currently registered.

──────────────────────────────────────────────────────────────────────────────
Run locally (dev):
    pip install flask requests
    python build_api.py

In production: serve with gunicorn behind nginx, or deploy as an Airflow
Plugin (see plugins/dynamic_dag_plugin.py).
──────────────────────────────────────────────────────────────────────────────
"""

from __future__ import annotations

import logging
import os
import sys

# Allow importing sibling dag modules when running standalone
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "dags"))

import requests
from flask import Flask, Response, jsonify, request

from dag_store import (
    delete_dag_definition,
    list_persisted_dag_ids,
    persist_dag_definition,
)
from dynamic_dag_factory import DYNAMIC_DAG_REGISTRY, build_dag_from_payload

log = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

app = Flask(__name__)

# ── Airflow REST API connection ───────────────────────────────────────────────
AIRFLOW_BASE_URL = os.getenv("AIRFLOW_BASE_URL", "http://localhost:8080")
AIRFLOW_USER     = os.getenv("AIRFLOW_API_USER", "airflow")
AIRFLOW_PASS     = os.getenv("AIRFLOW_API_PASS", "airflow")
AIRFLOW_AUTH     = (AIRFLOW_USER, AIRFLOW_PASS)


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────
def _airflow_get(path: str) -> requests.Response:
    return requests.get(
        f"{AIRFLOW_BASE_URL}/api/v1{path}",
        auth=AIRFLOW_AUTH,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )


def _airflow_post(path: str, body: dict) -> requests.Response:
    return requests.post(
        f"{AIRFLOW_BASE_URL}/api/v1{path}",
        json=body,
        auth=AIRFLOW_AUTH,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )


def _airflow_patch(path: str, body: dict) -> requests.Response:
    return requests.patch(
        f"{AIRFLOW_BASE_URL}/api/v1{path}",
        json=body,
        auth=AIRFLOW_AUTH,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )


def _error(msg: str, code: int = 400) -> tuple[Response, int]:
    return jsonify({"status": "error", "message": msg}), code


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 1 – BUILD ENDPOINT
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/api/v1/dag/build", methods=["POST"])
def build_dag():
    """
    Build a dynamic DAG from the supplied nodes payload.

    Request body
    ------------
    {
      "nodes": [
        {
          "id":                    "Helloworld-NODE1",
          "engine":                "NIFI",
          "executor_build_id":     "HelloworldCUSTOM-DB-TO-FILE-PULL",
          "executor_order_id":     "1",
          "executor_sequence_id":  "1"
        },
        ...
      ]
    }

    Response 201
    ------------
    {
      "status":       "success",
      "dag_id":       "dynamic_HelloworldCUSTOM_20240101120000123456",
      "node_count":   3,
      "task_mapping": {
        "Helloworld-NODE1": "Task1",
        "Helloworld-NODE2": "Task2",
        "Helloworld-NODE3": "Task3"
      },
      "sequence_groups": {
        "1": ["HelloworldCUSTOM-DB-TO-FILE-PULL"],
        "2": ["HelloworldPYTHON-CUSTOM-GENPROC-ARTIFACT1"],
        "3": ["HelloworldCUSTOM-FILE-TO-DB-PULL"]
      }
    }
    """
    payload = request.get_json(silent=True)
    if not payload:
        return _error("Request body must be valid JSON.")

    nodes = payload.get("nodes", [])
    if not nodes:
        return _error("'nodes' array is required and must not be empty.")

    # Validate each node has required fields
    required_fields = {"id", "engine", "executor_build_id", "executor_order_id", "executor_sequence_id"}
    for i, node in enumerate(nodes):
        missing = required_fields - set(node.keys())
        if missing:
            return _error(f"Node at index {i} is missing required fields: {missing}")

    try:
        dag_id, dag = build_dag_from_payload(payload)
    except Exception as exc:
        log.exception("DAG build failed")
        return _error(f"DAG build failed: {str(exc)}", 500)

    # Persist so the DAG survives restarts
    persist_dag_definition(dag_id, payload)

    # Unpause DAG via Airflow API so it can be triggered immediately
    try:
        _airflow_patch(f"/dags/{dag_id}", {"is_paused": False})
    except Exception:
        log.warning("Could not unpause DAG via Airflow API – DAG may be paused by default.")

    # Build human-readable response metadata
    ordered_nodes = sorted(nodes, key=lambda n: (
        int(n.get("executor_sequence_id", 1)),
        int(n.get("executor_order_id", 1)),
    ))
    task_mapping = {n["id"]: f"Task{i+1}" for i, n in enumerate(ordered_nodes)}

    from collections import defaultdict
    seq_groups: dict[str, list[str]] = defaultdict(list)
    for node in nodes:
        seq_groups[str(node["executor_sequence_id"])].append(node["executor_build_id"])

    return jsonify({
        "status":          "success",
        "dag_id":          dag_id,
        "node_count":      len(nodes),
        "task_mapping":    task_mapping,
        "sequence_groups": dict(seq_groups),
        "message":         (
            f"DAG '{dag_id}' created with {len(nodes)} task(s). "
            "Use the dag_id in the /run endpoint to trigger execution."
        ),
    }), 201


# ─────────────────────────────────────────────────────────────────────────────
# PHASE 2 – RUN ENDPOINT
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/api/v1/dag/run", methods=["POST"])
def run_dag():
    """
    Trigger a run of a previously built DAG.

    Request body
    ------------
    {
      "dag_id":      "dynamic_HelloworldCUSTOM_20240101120000123456",   ← from build response
      "dag_run_id":  "ghjfg_c7a0f976e687f8c",                          ← your unique run id
      "logical_date":"1991-12-13T15:26:56.506544600Z",
      "conf": {
        "correlation_id": "...",
        "global": {},
        "Task1": {
          "url":  "https://10.4.21.12:8445/scaffold/aitodb",
          "json": {
            "method":         "post",
            "headers":        {"Authorization": "****"},
            "timeout":        120,
            "node_runId":     "923423423423423443-12715111",
            "output_dir":     "//10.9.10.148/genesis-share/...",
            "correlation_id": "923423423423423443-12715111",
            "run_control_id": "run-rc-001"
          }
        },
        "Task2": { ... },
        "Task3": { ... }
      }
    }

    Response 200
    ------------
    {
      "status":       "triggered",
      "dag_id":       "dynamic_HelloworldCUSTOM_20240101120000123456",
      "dag_run_id":   "ghjfg_c7a0f976e687f8c",
      "airflow_response": { ... }
    }
    """
    payload = request.get_json(silent=True)
    if not payload:
        return _error("Request body must be valid JSON.")

    dag_id     = payload.get("dag_id")
    dag_run_id = payload.get("dag_run_id")
    conf       = payload.get("conf", {})

    if not dag_id:
        return _error("'dag_id' is required (returned from /build endpoint).")
    if not dag_run_id:
        return _error("'dag_run_id' is required.")

    # Verify DAG exists in our registry (or in persisted store)
    if dag_id not in DYNAMIC_DAG_REGISTRY and dag_id not in list_persisted_dag_ids():
        return _error(
            f"DAG '{dag_id}' not found. Build it first via POST /api/v1/dag/build.",
            404,
        )

    # Validate that conf contains at least Task1
    task_keys = [k for k in conf if k.startswith("Task")]
    if not task_keys:
        return _error(
            "The 'conf' object must contain at least one 'TaskN' key "
            "(e.g. Task1, Task2 …) matching the nodes from the build phase."
        )

    # Each TaskN must have url + json
    for tk in task_keys:
        tc = conf[tk]
        if "url" not in tc:
            return _error(f"'{tk}' is missing the required 'url' field.")
        if "json" not in tc:
            return _error(f"'{tk}' is missing the required 'json' field.")

    # Forward trigger to Airflow REST API
    trigger_body = {
        "dag_run_id":    dag_run_id,
        "logical_date":  payload.get("logical_date"),
        "conf":          conf,
    }
    # Remove None values
    trigger_body = {k: v for k, v in trigger_body.items() if v is not None}

    try:
        airflow_resp = _airflow_post(f"/dags/{dag_id}/dagRuns", trigger_body)
        airflow_data = airflow_resp.json()
    except Exception as exc:
        log.exception("Failed to trigger DAG run via Airflow API")
        return _error(f"Failed to trigger Airflow DAG run: {str(exc)}", 502)

    if airflow_resp.status_code not in (200, 201):
        return jsonify({
            "status":           "error",
            "dag_id":           dag_id,
            "airflow_status":   airflow_resp.status_code,
            "airflow_response": airflow_data,
        }), airflow_resp.status_code

    return jsonify({
        "status":           "triggered",
        "dag_id":           dag_id,
        "dag_run_id":       dag_run_id,
        "airflow_response": airflow_data,
        "message":          f"DAG '{dag_id}' triggered successfully. Poll /status/{dag_run_id} for updates.",
    }), 200


# ─────────────────────────────────────────────────────────────────────────────
# STATUS ENDPOINT
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/api/v1/dag/status/<dag_id>/<dag_run_id>", methods=["GET"])
def dag_run_status(dag_id: str, dag_run_id: str):
    """
    Poll the status of a specific DAG run.

    Response
    --------
    {
      "dag_id":     "...",
      "dag_run_id": "...",
      "state":      "running" | "success" | "failed",
      "start_date": "...",
      "end_date":   "...",
      "tasks":      [ { "task_id": "...", "state": "..." }, ... ]
    }
    """
    try:
        run_resp  = _airflow_get(f"/dags/{dag_id}/dagRuns/{dag_run_id}")
        task_resp = _airflow_get(f"/dags/{dag_id}/dagRuns/{dag_run_id}/taskInstances")
    except Exception as exc:
        return _error(f"Could not reach Airflow API: {str(exc)}", 502)

    run_data  = run_resp.json()
    task_data = task_resp.json()

    tasks = [
        {
            "task_id":   t.get("task_id"),
            "state":     t.get("state"),
            "start_date": t.get("start_date"),
            "end_date":   t.get("end_date"),
            "duration":   t.get("duration"),
        }
        for t in task_data.get("task_instances", [])
    ]

    return jsonify({
        "dag_id":     dag_id,
        "dag_run_id": dag_run_id,
        "state":      run_data.get("state"),
        "start_date": run_data.get("start_date"),
        "end_date":   run_data.get("end_date"),
        "tasks":      tasks,
    }), 200


# ─────────────────────────────────────────────────────────────────────────────
# LIST ENDPOINT
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/api/v1/dag/list", methods=["GET"])
def list_dags():
    """List all dynamically built DAGs."""
    dag_ids = list_persisted_dag_ids()
    return jsonify({
        "status":     "success",
        "count":      len(dag_ids),
        "dag_ids":    dag_ids,
    }), 200


# ─────────────────────────────────────────────────────────────────────────────
# DELETE ENDPOINT
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/api/v1/dag/<dag_id>", methods=["DELETE"])
def delete_dag(dag_id: str):
    """Decommission a dynamically built DAG."""
    deleted = delete_dag_definition(dag_id)
    if dag_id in DYNAMIC_DAG_REGISTRY:
        del DYNAMIC_DAG_REGISTRY[dag_id]
    if not deleted:
        return _error(f"DAG '{dag_id}' not found.", 404)
    return jsonify({"status": "success", "message": f"DAG '{dag_id}' deleted."}), 200


# ─────────────────────────────────────────────────────────────────────────────
# HEALTH CHECK
# ─────────────────────────────────────────────────────────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)), debug=False)
