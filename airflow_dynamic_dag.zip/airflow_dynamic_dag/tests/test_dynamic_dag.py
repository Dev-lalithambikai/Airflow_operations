"""
test_dynamic_dag.py
===================
Unit tests covering:
  • Build phase – DAG creation & sequencing logic
  • Run phase  – conf extraction & engine invocation
  • API endpoints (Flask test client)
  • Edge cases: empty nodes, bad sequence ids, missing task conf
"""

from __future__ import annotations

import json
import sys
import os
import unittest
from unittest.mock import MagicMock, patch

# ── Bootstrap path so we can import without installing ───────────────────────
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "dags"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "api"))


# ─────────────────────────────────────────────────────────────────────────────
# BUILD-PHASE TESTS  (pure Python, no Airflow scheduler needed)
# ─────────────────────────────────────────────────────────────────────────────
class TestSequencingLogic(unittest.TestCase):
    """Validate that executor_sequence_id drives correct task wiring."""

    BUILD_PAYLOAD_1 = {
        "nodes": [
            {"id": "N1", "engine": "NIFI",   "executor_build_id": "PREFIX-TASK-A", "executor_order_id": "1", "executor_sequence_id": "1"},
            {"id": "N2", "engine": "PYTHON", "executor_build_id": "PREFIX-TASK-B", "executor_order_id": "1", "executor_sequence_id": "1"},
            {"id": "N3", "engine": "NIFI",   "executor_build_id": "PREFIX-TASK-C", "executor_order_id": "1", "executor_sequence_id": "1"},
        ]
    }

    BUILD_PAYLOAD_2 = {
        "nodes": [
            {"id": "N1", "engine": "NIFI",   "executor_build_id": "PREFIX-TASK-A", "executor_order_id": "1", "executor_sequence_id": "1"},
            {"id": "N2", "engine": "PYTHON", "executor_build_id": "PREFIX-TASK-B", "executor_order_id": "1", "executor_sequence_id": "2"},
            {"id": "N3", "engine": "NIFI",   "executor_build_id": "PREFIX-TASK-C", "executor_order_id": "1", "executor_sequence_id": "2"},
        ]
    }

    BUILD_PAYLOAD_3 = {
        "nodes": [
            {"id": "N1", "engine": "NIFI",   "executor_build_id": "PREFIX-TASK-A", "executor_order_id": "1", "executor_sequence_id": "1"},
            {"id": "N2", "engine": "PYTHON", "executor_build_id": "PREFIX-TASK-B", "executor_order_id": "1", "executor_sequence_id": "2"},
            {"id": "N3", "engine": "NIFI",   "executor_build_id": "PREFIX-TASK-C", "executor_order_id": "1", "executor_sequence_id": "3"},
        ]
    }

    def _build(self, payload):
        """Helper: call build_dag_from_payload with Airflow mocked out."""
        with patch("dynamic_dag_factory.DAG") as mock_dag_cls, \
             patch("dynamic_dag_factory.PythonOperator") as mock_op_cls:

            mock_dag   = MagicMock()
            mock_dag_cls.return_value = mock_dag

            # Give each PythonOperator a unique task_id for dependency checks
            created_ops = []
            def make_op(**kwargs):
                op = MagicMock()
                op.task_id = kwargs.get("task_id", "unknown")
                created_ops.append(op)
                return op
            mock_op_cls.side_effect = make_op

            from dynamic_dag_factory import build_dag_from_payload
            dag_id, dag = build_dag_from_payload(payload)
            return dag_id, dag, created_ops

    def test_all_same_sequence_no_dependencies(self):
        """seq [1,1,1] → all tasks independent."""
        dag_id, dag, ops = self._build(self.BUILD_PAYLOAD_1)
        self.assertIn("dynamic_", dag_id)
        self.assertEqual(len(ops), 3)
        # No >> calls expected (no upstream dependencies set)
        for op in ops:
            op.__rshift__.assert_not_called()

    def test_dag_id_is_unique(self):
        """Two successive builds must produce distinct dag_ids."""
        id1, *_ = self._build(self.BUILD_PAYLOAD_1)
        id2, *_ = self._build(self.BUILD_PAYLOAD_1)
        # They differ because the timestamp suffix changes
        self.assertNotEqual(id1, id2)

    def test_task_ids_use_executor_build_id(self):
        """Task id (node name) must equal executor_build_id."""
        with patch("dynamic_dag_factory.DAG"), \
             patch("dynamic_dag_factory.PythonOperator") as mock_op_cls:
            created = []
            def make_op(**kwargs):
                op = MagicMock(); op.task_id = kwargs.get("task_id"); created.append(kwargs); return op
            mock_op_cls.side_effect = make_op
            from dynamic_dag_factory import build_dag_from_payload
            build_dag_from_payload(self.BUILD_PAYLOAD_2)

        build_ids = {n["executor_build_id"] for n in self.BUILD_PAYLOAD_2["nodes"]}
        task_ids  = {c["task_id"] for c in created}
        self.assertEqual(build_ids, task_ids)

    def test_empty_nodes_raises(self):
        """Empty nodes list must raise ValueError."""
        from dynamic_dag_factory import build_dag_from_payload
        with self.assertRaises((ValueError, Exception)):
            build_dag_from_payload({"nodes": []})


# ─────────────────────────────────────────────────────────────────────────────
# RUN-PHASE TESTS  (test _execute_node callable)
# ─────────────────────────────────────────────────────────────────────────────
class TestExecuteNode(unittest.TestCase):

    SAMPLE_CONF = {
        "correlation_id": "test-correlation",
        "global": {},
        "Task1": {
            "url": "https://10.4.21.12:8445/scaffold/aitodb",
            "json": {
                "method": "post",
                "headers": {"Authorization": "Bearer TOKEN"},
                "timeout": 60,
                "node_runId": "run-123",
            }
        }
    }

    def _make_context(self, conf):
        dag_run = MagicMock()
        dag_run.conf = conf
        return {"dag_run": dag_run}

    def test_successful_execution(self):
        with patch("dynamic_dag_factory._call_engine") as mock_call:
            mock_call.return_value = {"result": "ok"}
            from dynamic_dag_factory import _execute_node
            result = _execute_node(
                node_id="N1",
                task_key="Task1",
                engine="NIFI",
                **self._make_context(self.SAMPLE_CONF),
            )
            self.assertEqual(result, {"result": "ok"})
            mock_call.assert_called_once()
            call_args = mock_call.call_args
            self.assertEqual(call_args[0][0], "https://10.4.21.12:8445/scaffold/aitodb")

    def test_missing_task_key_raises(self):
        from dynamic_dag_factory import _execute_node
        ctx = self._make_context({"Task2": {"url": "http://x", "json": {}}})
        with self.assertRaises(ValueError, msg="Should raise when task_key missing from conf"):
            _execute_node(node_id="N1", task_key="Task1", engine="NIFI", **ctx)

    def test_missing_url_raises(self):
        bad_conf = {"Task1": {"json": {"headers": {}, "timeout": 10}}}
        from dynamic_dag_factory import _execute_node
        with self.assertRaises(ValueError, msg="Should raise when url missing"):
            _execute_node(node_id="N1", task_key="Task1", engine="NIFI",
                          **self._make_context(bad_conf))

    def test_headers_extracted_from_json(self):
        """Headers must be popped out of json body before it is sent to engine."""
        conf = {
            "Task1": {
                "url": "http://svc",
                "json": {
                    "headers": {"Authorization": "Bearer X"},
                    "timeout": 10,
                    "some_param": "value",
                }
            }
        }
        with patch("dynamic_dag_factory._call_engine") as mock_call:
            mock_call.return_value = {}
            from dynamic_dag_factory import _execute_node
            _execute_node(node_id="N1", task_key="Task1", engine="PYTHON",
                          **self._make_context(conf))
            _, body, headers, _ = mock_call.call_args[0]
            self.assertIn("Authorization", headers)
            self.assertNotIn("headers", body)     # must be stripped from body
            self.assertNotIn("timeout", body)     # must be stripped from body


# ─────────────────────────────────────────────────────────────────────────────
# API ENDPOINT TESTS  (Flask test client)
# ─────────────────────────────────────────────────────────────────────────────
class TestBuildAPI(unittest.TestCase):

    BUILD_PAYLOAD = {
        "nodes": [
            {"id": "Helloworld-NODE1", "engine": "NIFI",   "executor_build_id": "HelloworldCUSTOM-DB-TO-FILE-PULL",         "executor_order_id": "1", "executor_sequence_id": "1"},
            {"id": "Helloworld-NODE2", "engine": "PYTHON", "executor_build_id": "HelloworldPYTHON-CUSTOM-GENPROC-ARTIFACT1", "executor_order_id": "1", "executor_sequence_id": "2"},
            {"id": "Helloworld-NODE3", "engine": "NIFI",   "executor_build_id": "HelloworldCUSTOM-FILE-TO-DB-PULL",         "executor_order_id": "1", "executor_sequence_id": "3"},
        ]
    }

    RUN_PAYLOAD_TEMPLATE = {
        "dag_run_id":    "test_run_001",
        "logical_date":  "2024-01-01T00:00:00Z",
        "conf": {
            "correlation_id": "corr-001",
            "global": {},
            "Task1": {"url": "http://svc1", "json": {"method": "post", "headers": {}, "timeout": 30}},
            "Task2": {"url": "http://svc2", "json": {"method": "post", "headers": {}, "timeout": 30}},
            "Task3": {"url": "http://svc3", "json": {"method": "post", "headers": {}, "timeout": 30}},
        }
    }

    def setUp(self):
        # Patch heavy dependencies before importing build_api
        self.patcher_build   = patch("dynamic_dag_factory.build_dag_from_payload")
        self.patcher_persist = patch("dag_store.persist_dag_definition")
        self.patcher_airflow = patch("build_api._airflow_patch")
        self.patcher_list    = patch("dag_store.list_persisted_dag_ids")

        self.mock_build   = self.patcher_build.start()
        self.mock_persist = self.patcher_persist.start()
        self.mock_airflow = self.patcher_airflow.start()
        self.mock_list    = self.patcher_list.start()

        # Default return values
        self.mock_build.return_value   = ("dynamic_Helloworld_20240101", MagicMock())
        self.mock_persist.return_value = None
        self.mock_airflow.return_value = MagicMock(status_code=200)
        self.mock_list.return_value    = ["dynamic_Helloworld_20240101"]

        import build_api
        build_api.app.config["TESTING"] = True
        self.client = build_api.app.test_client()

    def tearDown(self):
        self.patcher_build.stop()
        self.patcher_persist.stop()
        self.patcher_airflow.stop()
        self.patcher_list.stop()

    def test_build_returns_201_with_dag_id(self):
        resp = self.client.post(
            "/api/v1/dag/build",
            json=self.BUILD_PAYLOAD,
            content_type="application/json",
        )
        self.assertEqual(resp.status_code, 201)
        data = resp.get_json()
        self.assertEqual(data["status"], "success")
        self.assertIn("dag_id", data)
        self.assertIn("task_mapping", data)

    def test_build_empty_nodes_returns_400(self):
        resp = self.client.post("/api/v1/dag/build", json={"nodes": []})
        self.assertEqual(resp.status_code, 400)

    def test_build_no_body_returns_400(self):
        resp = self.client.post("/api/v1/dag/build", data="not json")
        self.assertEqual(resp.status_code, 400)

    def test_run_missing_dag_id_returns_400(self):
        payload = dict(self.RUN_PAYLOAD_TEMPLATE)
        payload.pop("dag_run_id", None)
        payload["dag_id"] = None
        resp = self.client.post("/api/v1/dag/run", json=payload)
        self.assertEqual(resp.status_code, 400)

    def test_run_unknown_dag_returns_404(self):
        self.mock_list.return_value = []  # empty store
        import build_api
        build_api.DYNAMIC_DAG_REGISTRY.clear()

        payload = dict(self.RUN_PAYLOAD_TEMPLATE)
        payload["dag_id"] = "nonexistent_dag"
        resp = self.client.post("/api/v1/dag/run", json=payload)
        self.assertEqual(resp.status_code, 404)

    def test_health_endpoint(self):
        resp = self.client.get("/health")
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_json()["status"], "ok")

    def test_list_endpoint(self):
        resp = self.client.get("/api/v1/dag/list")
        self.assertEqual(resp.status_code, 200)
        data = resp.get_json()
        self.assertIn("dag_ids", data)


if __name__ == "__main__":
    unittest.main(verbosity=2)
