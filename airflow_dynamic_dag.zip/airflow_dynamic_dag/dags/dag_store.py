"""
dag_store.py
============
Persistence layer for dynamically built DAGs.

When the Build API creates a new DAG it calls `persist_dag_definition()` to
write the original build-phase payload + derived dag_id to a JSON file on
disk.  On every scheduler restart, `load_all_persisted_dags()` replays those
files to restore all dynamic DAGs into Airflow's DAG bag.

Directory layout
----------------
  $AIRFLOW_HOME/dynamic_dags/
      <dag_id>.json          ← one file per built DAG
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)

# ── Storage directory (override with env var if needed) ───────────────────────
STORE_DIR = Path(os.getenv("DYNAMIC_DAG_STORE", "/opt/airflow/dynamic_dags"))
STORE_DIR.mkdir(parents=True, exist_ok=True)


def persist_dag_definition(dag_id: str, build_payload: dict) -> Path:
    """
    Write the build payload (+ dag_id) to a JSON file so the DAG can be
    reconstructed after scheduler restarts.
    """
    record = {"dag_id": dag_id, "build_payload": build_payload}
    dest   = STORE_DIR / f"{dag_id}.json"
    dest.write_text(json.dumps(record, indent=2))
    log.info("DAG definition persisted → %s", dest)
    return dest


def load_all_persisted_dags() -> list[dict]:
    """
    Return all persisted dag definitions as a list of dicts:
      [{"dag_id": "...", "build_payload": {...}}, ...]
    """
    defs = []
    for f in STORE_DIR.glob("*.json"):
        try:
            defs.append(json.loads(f.read_text()))
        except Exception as exc:
            log.warning("Could not load persisted DAG from %s: %s", f, exc)
    log.info("Loaded %d persisted DAG definition(s) from %s.", len(defs), STORE_DIR)
    return defs


def delete_dag_definition(dag_id: str) -> bool:
    """Remove a persisted definition (e.g. when a DAG is decommissioned)."""
    path = STORE_DIR / f"{dag_id}.json"
    if path.exists():
        path.unlink()
        log.info("Deleted persisted definition for DAG '%s'.", dag_id)
        return True
    return False


def list_persisted_dag_ids() -> list[str]:
    return [f.stem for f in STORE_DIR.glob("*.json")]
