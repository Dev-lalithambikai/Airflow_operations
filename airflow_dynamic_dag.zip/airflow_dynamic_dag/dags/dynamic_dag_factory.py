"""
dynamic_dag_factory.py
======================
PHASE 1 – BUILD PHASE
---------------------
Listens for a REST payload (delivered via Airflow's "dag_run conf" or the
custom /build endpoint in api/build_api.py).  For each unique dag_id it
creates a brand-new Airflow DAG on-the-fly and persists it so Airflow's
scheduler can pick it up immediately.

PHASE 2 – RUN PHASE
--------------------
The dag that was built in Phase-1 already knows its node topology.
When triggered with a run-phase payload the individual PythonOperator tasks
read their own conf slice (Task1 / Task2 / Task3 …) and call the supplied
URL + json body via requests, forwarding headers transparently.

Node sequencing rules (executor_sequence_id):
  • same id across all nodes  → all run in parallel (no dependencies)
  • mixed ids                 → nodes with id N only start after ALL nodes
                                with id N-1 have succeeded.
  • if any node in group N-1 fails → dag is marked FAILED immediately.
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Any

import requests
from airflow import DAG
from airflow.models import DagBag, DagModel
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
from airflow.utils.db import provide_session
from airflow.utils.state import State

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# CONSTANTS
# ──────────────────────────────────────────────────────────────────────────────
DEFAULT_ARGS = {
    "owner": "airflow",
    "depends_on_past": False,
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 0,
    "retry_delay": timedelta(minutes=1),
}

# In-memory registry so the Airflow scheduler can discover dynamically built DAGs
# (populated by build_dag_from_payload)
DYNAMIC_DAG_REGISTRY: dict[str, DAG] = {}


# ──────────────────────────────────────────────────────────────────────────────
# ENGINE → HTTP METHOD ROUTER
# ──────────────────────────────────────────────────────────────────────────────
SUPPORTED_ENGINES = {"NIFI", "PYTHON", "PYHTON", "GENPROC", "RULESET", "DATASET"}

def _call_engine(url: str, payload: dict, headers: dict, timeout: int = 120) -> dict:
    """
    Generic HTTP POST to any engine endpoint (NiFi, Python service,
    GenProc, Ruleset, Dataset).  Returns the JSON response or raises.
    """
    log.info("Calling engine at %s | payload keys: %s", url, list(payload.keys()))
    try:
        resp = requests.post(
            url,
            json=payload,
            headers=headers,
            timeout=timeout,
            verify=False,          # adjust per environment (mTLS / self-signed certs)
        )
        resp.raise_for_status()
        log.info("Engine response [%s]: %s", resp.status_code, resp.text[:300])
        return resp.json() if resp.content else {}
    except requests.exceptions.HTTPError as exc:
        log.error("HTTP error from engine: %s", exc)
        raise
    except requests.exceptions.ConnectionError as exc:
        log.error("Connection error reaching engine at %s: %s", url, exc)
        raise
    except Exception as exc:
        log.error("Unexpected error calling engine: %s", exc)
        raise


# ──────────────────────────────────────────────────────────────────────────────
# TASK CALLABLE  (used by every PythonOperator node)
# ──────────────────────────────────────────────────────────────────────────────
def _execute_node(
    node_id: str,
    task_key: str,        # e.g. "Task1"
    engine: str,
    **context: Any,
) -> None:
    """
    Run-phase callable injected into every PythonOperator.

    Reads the run-time conf slice for `task_key`, extracts url / headers /
    json-body and fires the HTTP call to the target engine.
    """
    dag_run_conf: dict = context["dag_run"].conf or {}
    log.info("[%s] Full dag_run conf keys: %s", node_id, list(dag_run_conf.keys()))

    task_conf: dict = dag_run_conf.get(task_key)
    if not task_conf:
        raise ValueError(
            f"Node '{node_id}' expected conf key '{task_key}' but it was not present. "
            f"Available keys: {list(dag_run_conf.keys())}"
        )

    url: str        = task_conf.get("url", "")
    json_body: dict = task_conf.get("json", {})
    headers: dict   = json_body.pop("headers", {})   # extract & remove from body
    timeout: int    = json_body.pop("timeout", 120)

    if not url:
        raise ValueError(f"Node '{node_id}' conf has no 'url' key under '{task_key}'.")

    log.info(
        "[%s] engine=%s | url=%s | timeout=%s | body_keys=%s",
        node_id, engine, url, timeout, list(json_body.keys()),
    )

    result = _call_engine(url, json_body, headers, timeout)
    log.info("[%s] SUCCESS. Response: %s", node_id, result)

    # Push result to XCom so downstream tasks / monitoring can read it
    return result


# ──────────────────────────────────────────────────────────────────────────────
# BUILD PHASE  –  DAG FACTORY
# ──────────────────────────────────────────────────────────────────────────────
def build_dag_from_payload(payload: dict) -> tuple[str, DAG]:
    """
    PHASE 1 entry-point.

    Accepts the build-phase JSON payload, constructs an Airflow DAG with the
    correct task topology derived from executor_sequence_id, registers it in
    DYNAMIC_DAG_REGISTRY and returns (dag_id, dag).

    Sequencing logic
    ----------------
    Nodes are grouped by executor_sequence_id (converted to int).
    Groups are sorted ascending.  Each group depends on ALL tasks in the
    previous group.  Tasks within a group have no inter-dependencies.

    Example:
        seq_ids = [1, 1, 1]  →  t1, t2, t3 run in parallel (no deps)
        seq_ids = [1, 2, 2]  →  t1 → (t2 ∥ t3)
        seq_ids = [1, 2, 3]  →  t1 → t2 → t3  (strict chain)
    """
    nodes: list[dict] = payload.get("nodes", [])
    if not nodes:
        raise ValueError("Payload must contain at least one node under 'nodes'.")

    # ── Derive a unique DAG id from the first node's build-id prefix ─────────
    prefix   = nodes[0]["executor_build_id"].split("-")[0]          # e.g. "HelloworldCUSTOM"
    dag_id   = f"dynamic_{prefix}_{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}"

    log.info("Building DAG '%s' with %d node(s).", dag_id, len(nodes))

    dag = DAG(
        dag_id=dag_id,
        default_args=DEFAULT_ARGS,
        description=f"Dynamically built DAG – {dag_id}",
        schedule_interval=None,          # only triggered via API (Run phase)
        start_date=days_ago(1),
        catchup=False,
        tags=["dynamic", "api-driven"],
        render_template_as_native_obj=True,
    )

    # ── Group nodes by sequence ───────────────────────────────────────────────
    groups: dict[int, list[dict]] = defaultdict(list)
    for node in nodes:
        seq = int(node.get("executor_sequence_id", 1))
        groups[seq].append(node)

    sorted_sequences = sorted(groups.keys())

    # ── Create PythonOperator tasks ───────────────────────────────────────────
    # We assign Task1, Task2, … in the ORDER nodes appear (executor_order_id tiebreak).
    ordered_nodes = sorted(nodes, key=lambda n: (
        int(n.get("executor_sequence_id", 1)),
        int(n.get("executor_order_id", 1)),
    ))
    node_to_task_key = {
        n["id"]: f"Task{i + 1}" for i, n in enumerate(ordered_nodes)
    }

    airflow_tasks: dict[str, PythonOperator] = {}

    for node in nodes:
        node_id      = node["id"]
        build_id     = node["executor_build_id"]
        engine       = node.get("engine", "UNKNOWN").upper()
        task_key     = node_to_task_key[node_id]

        task = PythonOperator(
            task_id=build_id,                   # rule 1: build_id is the task/node name
            python_callable=_execute_node,
            op_kwargs={
                "node_id":  node_id,
                "task_key": task_key,
                "engine":   engine,
            },
            provide_context=True,
            dag=dag,
        )
        airflow_tasks[node_id] = task

    # ── Wire dependencies by sequence group ───────────────────────────────────
    prev_group_tasks: list[PythonOperator] = []

    for seq in sorted_sequences:
        current_group_tasks = [
            airflow_tasks[n["id"]] for n in groups[seq]
        ]
        if prev_group_tasks:
            # Every task in this group depends on EVERY task in the prior group
            for prev_task in prev_group_tasks:
                for cur_task in current_group_tasks:
                    prev_task >> cur_task
        prev_group_tasks = current_group_tasks

    # ── Register in global registry so Airflow scheduler discovers it ─────────
    DYNAMIC_DAG_REGISTRY[dag_id] = dag
    globals()[dag_id] = dag      # Airflow scans globals() in each dag file

    log.info("DAG '%s' registered successfully.", dag_id)
    return dag_id, dag


# ──────────────────────────────────────────────────────────────────────────────
# EXPOSE REGISTRY TO AIRFLOW SCHEDULER
# ──────────────────────────────────────────────────────────────────────────────
# Airflow imports this module and scans globals() for DAG objects.
# Any DAG registered via build_dag_from_payload() is automatically picked up.
for _dag_id, _dag in DYNAMIC_DAG_REGISTRY.items():
    globals()[_dag_id] = _dag
