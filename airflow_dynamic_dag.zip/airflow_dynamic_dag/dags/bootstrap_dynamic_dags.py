"""
bootstrap_dynamic_dags.py
=========================
Placed in $AIRFLOW_HOME/dags/.  Airflow imports every .py file in the dags
folder; this file replays all persisted DAG definitions so dynamically built
DAGs survive scheduler / webserver restarts.

No manual intervention required – just drop this file alongside
dynamic_dag_factory.py and dag_store.py.
"""

from __future__ import annotations

import logging

from dag_store import load_all_persisted_dags
from dynamic_dag_factory import build_dag_from_payload, DYNAMIC_DAG_REGISTRY

log = logging.getLogger(__name__)

log.info("Bootstrap: replaying persisted dynamic DAGs …")

for record in load_all_persisted_dags():
    dag_id       = record["dag_id"]
    build_payload = record["build_payload"]

    if dag_id in DYNAMIC_DAG_REGISTRY:
        log.debug("DAG '%s' already in registry – skipping.", dag_id)
        continue

    try:
        built_dag_id, dag = build_dag_from_payload(build_payload)
        # Inject into this module's globals so Airflow picks it up
        globals()[built_dag_id] = dag
        log.info("Bootstrap: restored DAG '%s'.", built_dag_id)
    except Exception as exc:
        log.error("Bootstrap: failed to restore DAG for record %s: %s", dag_id, exc)

log.info("Bootstrap complete. %d DAG(s) in registry.", len(DYNAMIC_DAG_REGISTRY))
