"""
dynamic_dag_plugin.py
=====================
Registers the Build/Run Flask blueprint as an Airflow Plugin so it is served
at the same port as the Airflow webserver (no separate Flask process needed).

Endpoint prefix when running as plugin:  /dynamic-dag-api/...
e.g.  POST http://airflow:8080/dynamic-dag-api/api/v1/dag/build

To enable: place this file in $AIRFLOW_HOME/plugins/
"""

from __future__ import annotations

import os
import sys

# Allow importing from the api folder
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "api"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "dags"))

from flask import Blueprint
from airflow.plugins_manager import AirflowPlugin

from build_api import app as flask_app   # reuse all routes

# Wrap existing Flask app as a Blueprint
dynamic_dag_blueprint = Blueprint(
    "dynamic_dag_api",
    __name__,
    url_prefix="/dynamic-dag-api",
)

# Re-register all routes from build_api onto the blueprint
for rule in flask_app.url_map.iter_rules():
    if rule.endpoint == "static":
        continue
    view_func = flask_app.view_functions[rule.endpoint]
    dynamic_dag_blueprint.add_url_rule(
        rule.rule,
        endpoint=rule.endpoint,
        view_func=view_func,
        methods=rule.methods,
    )


class DynamicDagPlugin(AirflowPlugin):
    name = "dynamic_dag_plugin"
    flask_blueprints = [dynamic_dag_blueprint]
    appbuilder_views = []
    appbuilder_menu_items = []
    global_operator_extra_links = []
