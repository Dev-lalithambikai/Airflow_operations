# Dynamic Airflow DAG Pipeline
## Two-Phase Architecture: Build → Run

---

## Table of Contents
1. [Architecture Overview](#1-architecture-overview)
2. [Project Structure](#2-project-structure)
3. [Phase 1 – Build Phase](#3-phase-1--build-phase)
4. [Phase 2 – Run Phase](#4-phase-2--run-phase)
5. [Sequencing Rules](#5-sequencing-rules)
6. [Engine Routing](#6-engine-routing)
7. [API Reference](#7-api-reference)
8. [Setup & Deployment](#8-setup--deployment)
9. [End-to-End Example](#9-end-to-end-example)
10. [Design Decisions & Extensibility](#10-design-decisions--extensibility)

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────┐
│                        EXTERNAL TRIGGER                             │
│              (REST client, scheduler, upstream system)              │
└──────────────────────┬──────────────────────┬───────────────────────┘
                       │                      │
               POST /build              POST /run
               (Phase 1)                (Phase 2)
                       │                      │
┌──────────────────────▼──────────────────────▼───────────────────────┐
│                   Dynamic DAG API  (Flask / Gunicorn)               │
│                         build_api.py  :5000                         │
│                                                                     │
│  /api/v1/dag/build  →  build_dag_from_payload()  →  returns dag_id │
│  /api/v1/dag/run    →  Airflow REST API trigger  →  dag run starts  │
│  /api/v1/dag/status →  Airflow REST API poll     →  run state       │
└──────────────────────┬──────────────────────────────────────────────┘
                       │  Airflow REST API  (port 8080)
┌──────────────────────▼──────────────────────────────────────────────┐
│                      Apache Airflow                                 │
│                                                                     │
│   Webserver / Scheduler / Metadata DB (Postgres)                   │
│                                                                     │
│   DAG Registry                                                      │
│   ┌─────────────────────────────────────────────────────────┐      │
│   │  dynamic_<prefix>_<timestamp>                           │      │
│   │                                                         │      │
│   │  [Group seq=1]          [Group seq=2]  [Group seq=3]   │      │
│   │  TaskA  TaskB  ──────►  TaskC  TaskD  ──────►  TaskE   │      │
│   │  (parallel)             (parallel)             (serial) │      │
│   └─────────────────────────────────────────────────────────┘      │
└──────────────────────┬──────────────────────────────────────────────┘
                       │  HTTP POST (url from Task conf)
          ┌────────────┼────────────┬──────────────┐
          ▼            ▼            ▼               ▼
       NiFi API    Python Svc   GenProc API    Ruleset/Dataset
   (REST trigger) (REST job)  (REST artifact)  (REST endpoint)
```

---

## 2. Project Structure

```
airflow_dynamic_dag/
│
├── dags/
│   ├── dynamic_dag_factory.py      ← CORE: DAG builder + task callable
│   ├── dag_store.py                ← Persistence: save/load dag definitions
│   └── bootstrap_dynamic_dags.py   ← Startup: replay persisted DAGs
│
├── api/
│   └── build_api.py                ← Flask REST API (Build + Run endpoints)
│
├── plugins/
│   └── dynamic_dag_plugin.py       ← Mounts Flask API inside Airflow webserver
│
├── tests/
│   └── test_dynamic_dag.py         ← Unit tests
│
├── docker-compose.yml              ← Local dev stack
├── Dockerfile.api                  ← Flask API container
├── requirements.txt
└── README.md
```

---

## 3. Phase 1 – Build Phase

### What happens

```
POST /api/v1/dag/build
        │
        ▼
  Validate payload
  (nodes array, required fields)
        │
        ▼
  build_dag_from_payload()
  ┌─────────────────────────────────────────────────────────┐
  │  1. Generate unique dag_id                              │
  │     "dynamic_{prefix}_{YYYYMMDDHHMMSSffffff}"          │
  │                                                         │
  │  2. Group nodes by executor_sequence_id                 │
  │     groups = { 1: [N1], 2: [N2, N3] }                 │
  │                                                         │
  │  3. Sort groups ascending (1 → 2 → 3 …)               │
  │                                                         │
  │  4. Assign Task keys in seq+order order                 │
  │     N1→Task1, N2→Task2, N3→Task3                       │
  │                                                         │
  │  5. Create PythonOperator per node                      │
  │     task_id = executor_build_id  (rule 1)              │
  │     op_kwargs = {node_id, task_key, engine}            │
  │                                                         │
  │  6. Wire dependencies                                   │
  │     prev_group tasks >> current_group tasks             │
  │                                                         │
  │  7. Register DAG in globals() + DYNAMIC_DAG_REGISTRY   │
  └─────────────────────────────────────────────────────────┘
        │
        ▼
  persist_dag_definition(dag_id, payload)
  → writes /opt/airflow/dynamic_dags/{dag_id}.json
        │
        ▼
  Unpause DAG via Airflow REST API
        │
        ▼
  Return 201 { dag_id, task_mapping, sequence_groups }
```

### Build Request

```json
POST /api/v1/dag/build
Content-Type: application/json

{
  "nodes": [
    {
      "id":                   "Helloworld-NODE1",
      "engine":               "NIFI",
      "executor_build_id":    "HelloworldCUSTOM-DB-TO-FILE-PULL",
      "executor_order_id":    "1",
      "executor_sequence_id": "1"
    },
    {
      "id":                   "Helloworld-NODE2",
      "engine":               "PYTHON",
      "executor_build_id":    "HelloworldPYTHON-CUSTOM-GENPROC-ARTIFACT1",
      "executor_order_id":    "1",
      "executor_sequence_id": "2"
    },
    {
      "id":                   "Helloworld-NODE3",
      "engine":               "NIFI",
      "executor_build_id":    "HelloworldCUSTOM-FILE-TO-DB-PULL",
      "executor_order_id":    "1",
      "executor_sequence_id": "3"
    }
  ]
}
```

### Build Response

```json
HTTP 201 Created

{
  "status":    "success",
  "dag_id":    "dynamic_HelloworldCUSTOM_20240315143022123456",
  "node_count": 3,
  "task_mapping": {
    "Helloworld-NODE1": "Task1",
    "Helloworld-NODE2": "Task2",
    "Helloworld-NODE3": "Task3"
  },
  "sequence_groups": {
    "1": ["HelloworldCUSTOM-DB-TO-FILE-PULL"],
    "2": ["HelloworldPYTHON-CUSTOM-GENPROC-ARTIFACT1"],
    "3": ["HelloworldCUSTOM-FILE-TO-DB-PULL"]
  },
  "message": "DAG 'dynamic_HelloworldCUSTOM_20240315143022123456' created with 3 task(s)."
}
```

> **Save the `dag_id`** — you will pass it in every Run phase call.

---

## 4. Phase 2 – Run Phase

### What happens

```
POST /api/v1/dag/run
        │
        ▼
  Validate: dag_id exists?  task confs present?  url in each task?
        │
        ▼
  Forward to Airflow REST API:
  POST /api/v1/dags/{dag_id}/dagRuns
  body = { dag_run_id, logical_date, conf: {Task1, Task2, Task3} }
        │
        ▼
  Airflow Scheduler picks up the dag run
        │
        ▼
  For each task group (in sequence order):
  ┌─────────────────────────────────────────────────────────┐
  │  PythonOperator executes _execute_node()                │
  │                                                         │
  │  1. Read dag_run.conf["TaskN"]                         │
  │  2. Extract url, headers (from json), timeout          │
  │  3. POST url with json body + headers                  │
  │  4. Engine responds → push to XCom                     │
  │  5. If exception → task FAILED → group stops           │
  │     → if any upstream group fails → DAG = FAILED       │
  └─────────────────────────────────────────────────────────┘
```

### Run Request

```json
POST /api/v1/dag/run
Content-Type: application/json

{
  "dag_id":       "dynamic_HelloworldCUSTOM_20240315143022123456",
  "dag_run_id":   "ghjfg_c7a0f976e687f8c",
  "logical_date": "1991-12-13T15:26:56.506544600Z",
  "conf": {
    "correlation_id": "e4323232-43-4532-efwe-0f42387111",
    "global": {},
    "Task1": {
      "url": "https://10.4.21.12:8445/scaffold/aitodb",
      "json": {
        "method":         "post",
        "headers":        { "Authorization": "****" },
        "timeout":        120,
        "node_runId":     "923423423423423443-12715111",
        "output_dir":     "//10.9.10.148/genesis-share/Nifi/output/Trade",
        "correlation_id": "923423423423423443-12715111",
        "run_control_id": "run-rc-001"
      }
    },
    "Task2": {
      "url": "http://10.3.26.78:2181/jobs",
      "json": {
        "method":     "post",
        "headers":    { "Authorization": "****" },
        "timeout":    120,
        "node_runId": "923423423423423443-12715111"
      }
    },
    "Task3": {
      "url": "https://10.8.65.33:8446/file/transfer",
      "json": {
        "method":     "post",
        "headers":    { "Authorization": "****" },
        "timeout":    120,
        "node_runId": "923423423423423443-12715111"
      }
    }
  }
}
```

### Run Response

```json
HTTP 200 OK

{
  "status":     "triggered",
  "dag_id":     "dynamic_HelloworldCUSTOM_20240315143022123456",
  "dag_run_id": "ghjfg_c7a0f976e687f8c",
  "airflow_response": { ... },
  "message":    "DAG triggered. Poll /status/{dag_run_id} for updates."
}
```

### Payload Routing — How Task1/Task2/Task3 Maps to Nodes

```
Build phase assigns keys at creation time, sorted by seq then order:

  Node seq=1, order=1  → Task1
  Node seq=2, order=1  → Task2
  Node seq=3, order=1  → Task3

At run time each PythonOperator reads only its own slice:
  HelloworldCUSTOM-DB-TO-FILE-PULL     reads  conf["Task1"]
  HelloworldPYTHON-CUSTOM-GENPROC      reads  conf["Task2"]
  HelloworldCUSTOM-FILE-TO-DB-PULL     reads  conf["Task3"]

The url inside Task1.json is called with Task1.json.{everything except headers & timeout}
as the POST body, and Task1.json.headers as HTTP headers.
```

---

## 5. Sequencing Rules

| executor_sequence_id values | DAG shape               | Dependency wire         |
|-----------------------------|-------------------------|-------------------------|
| `[1, 1, 1]`                 | All 3 run in parallel   | None                    |
| `[1, 2, 2]`                 | N1 → (N2 ∥ N3)          | N1 >> N2, N1 >> N3      |
| `[1, 2, 3]`                 | N1 → N2 → N3 (chain)    | N1 >> N2, N2 >> N3      |
| `[1, 1, 2]`                 | (N1 ∥ N2) → N3          | N1 >> N3, N2 >> N3      |

**Failure propagation:**  
If any task in group N fails, Airflow marks dependent tasks in group N+1 as `upstream_failed` and the entire DAG run ends as `failed`. This satisfies the requirement: *"if 1st node fails → stop DAG as failure"*.

---

## 6. Engine Routing

All engines (NiFi, Python service, GenProc, Ruleset, Dataset) share the same `_execute_node` callable and `_call_engine` HTTP POST function. The engine field is logged for observability but the actual connection is driven by the `url` in the run-phase payload.

```
engine = "NIFI"     → calls url from Task1.json (e.g. NiFi REST endpoint)
engine = "PYTHON"   → calls url from Task2.json (e.g. Python microservice)
engine = "GENPROC"  → calls url from Task3.json (e.g. GenProc service)
engine = "RULESET"  → calls url from TaskN.json
engine = "DATASET"  → calls url from TaskN.json
```

To add engine-specific behavior (e.g. different auth or retry logic), add an `if engine == "NIFI"` branch inside `_call_engine()`.

---

## 7. API Reference

| Method | Path | Phase | Description |
|--------|------|-------|-------------|
| `POST` | `/api/v1/dag/build` | Build | Create dynamic DAG, returns `dag_id` |
| `POST` | `/api/v1/dag/run` | Run | Trigger a DAG run with task payloads |
| `GET`  | `/api/v1/dag/status/{dag_id}/{dag_run_id}` | Run | Poll run state + task states |
| `GET`  | `/api/v1/dag/list` | Both | List all built DAGs |
| `DELETE` | `/api/v1/dag/{dag_id}` | Both | Decommission a DAG |
| `GET`  | `/health` | — | Health check |

---

## 8. Setup & Deployment

### Local (Docker Compose)

```bash
# 1. Clone / copy project
cd airflow_dynamic_dag

# 2. Start stack (Postgres + Airflow + Flask API)
docker-compose up --build -d

# 3. Wait for Airflow to initialise (~30s), then open:
#    Airflow UI  → http://localhost:8080  (user: airflow / airflow)
#    DAG API     → http://localhost:5000
```

### Without Docker (bare metal)

```bash
pip install apache-airflow==2.8.1 flask requests gunicorn

# 1. Start Airflow
export AIRFLOW_HOME=~/airflow
airflow db migrate
airflow users create -u airflow -p airflow -r Admin -e a@b.com -f A -l B
airflow webserver &
airflow scheduler &

# 2. Start Flask API
export AIRFLOW_BASE_URL=http://localhost:8080
export DYNAMIC_DAG_STORE=~/airflow/dynamic_dags
python api/build_api.py
```

### Run Tests

```bash
pip install apache-airflow flask requests
python -m pytest tests/ -v
```

---

## 9. End-to-End Example

### Step 1 — Build the DAG

```bash
curl -X POST http://localhost:5000/api/v1/dag/build \
  -H "Content-Type: application/json" \
  -d '{
    "nodes": [
      {"id":"N1","engine":"NIFI","executor_build_id":"HelloworldCUSTOM-DB-TO-FILE-PULL","executor_order_id":"1","executor_sequence_id":"1"},
      {"id":"N2","engine":"PYTHON","executor_build_id":"HelloworldPYTHON-CUSTOM-GENPROC-ARTIFACT1","executor_order_id":"1","executor_sequence_id":"2"},
      {"id":"N3","engine":"NIFI","executor_build_id":"HelloworldCUSTOM-FILE-TO-DB-PULL","executor_order_id":"1","executor_sequence_id":"3"}
    ]
  }'

# Response:
# { "dag_id": "dynamic_HelloworldCUSTOM_20240315143022123456", ... }
```

### Step 2 — Run the DAG

```bash
DAG_ID="dynamic_HelloworldCUSTOM_20240315143022123456"

curl -X POST http://localhost:5000/api/v1/dag/run \
  -H "Content-Type: application/json" \
  -d "{
    \"dag_id\": \"$DAG_ID\",
    \"dag_run_id\": \"run_$(date +%s)\",
    \"conf\": {
      \"Task1\": {\"url\":\"https://nifi-host/api/trigger\",\"json\":{\"headers\":{\"Authorization\":\"Bearer TOKEN\"},\"timeout\":120,\"node_runId\":\"abc123\"}},
      \"Task2\": {\"url\":\"http://python-svc/jobs\",\"json\":{\"headers\":{\"Authorization\":\"Bearer TOKEN\"},\"timeout\":120,\"node_runId\":\"abc123\"}},
      \"Task3\": {\"url\":\"https://genproc-host/transfer\",\"json\":{\"headers\":{\"Authorization\":\"Bearer TOKEN\"},\"timeout\":120,\"node_runId\":\"abc123\"}}
    }
  }"
```

### Step 3 — Poll Status

```bash
curl http://localhost:5000/api/v1/dag/status/$DAG_ID/run_1710511822

# Response:
# {
#   "state": "success",
#   "tasks": [
#     {"task_id": "HelloworldCUSTOM-DB-TO-FILE-PULL", "state": "success"},
#     {"task_id": "HelloworldPYTHON-CUSTOM-GENPROC-ARTIFACT1", "state": "success"},
#     {"task_id": "HelloworldCUSTOM-FILE-TO-DB-PULL", "state": "success"}
#   ]
# }
```

---

## 10. Design Decisions & Extensibility

### Why PythonOperator for all engines?
All supported engines (NiFi, Python, GenProc, Ruleset, Dataset) expose HTTP REST endpoints. A single `PythonOperator` calling `requests.post()` is the simplest, most maintainable approach. There is no NiFi-specific Airflow provider that handles your custom authentication pattern.

### Why Flask separately from Airflow?
The build endpoint must write to the filesystem and modify the DAG registry synchronously — these are side effects incompatible with Airflow's stateless task design. A separate Flask service (or Airflow Plugin) keeps concerns clean.

### Failure propagation
Airflow's default `depends_on_past=False` + `trigger_rule=ALL_SUCCESS` (the default) guarantees that if group N has any failure, all tasks in group N+1 will be skipped/upstream-failed, and the DAG run is marked `failed`.

### Future: Response callback
The `_execute_node` callable pushes the engine response to Airflow XCom. A future callback task at the end of the DAG can read all XCom values and POST a consolidated result back to the originating system using the `correlation_id` from the run conf.

### Future: Adding a new engine type
1. Add the engine name to `SUPPORTED_ENGINES` in `dynamic_dag_factory.py`.
2. Add an `elif engine == "MY_ENGINE":` branch in `_call_engine()` if it needs special auth, retry, or protocol logic.
3. No other changes needed — the routing is data-driven via the `url` in the run payload.
